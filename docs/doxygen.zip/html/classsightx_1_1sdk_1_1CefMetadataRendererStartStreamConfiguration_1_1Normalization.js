var classsightx_1_1sdk_1_1CefMetadataRendererStartStreamConfiguration_1_1Normalization =
[
    [ "Normalization", "classsightx_1_1sdk_1_1CefMetadataRendererStartStreamConfiguration_1_1Normalization.html#a92556d2b137583d60dbb618e1fb04fc2", null ],
    [ "Normalization", "classsightx_1_1sdk_1_1CefMetadataRendererStartStreamConfiguration_1_1Normalization.html#a62781080aa0ba22df8bb397c8ee4d80b", null ],
    [ "Normalization", "classsightx_1_1sdk_1_1CefMetadataRendererStartStreamConfiguration_1_1Normalization.html#a52d042ef25c0806c028c41cfaa94f79d", null ],
    [ "~Normalization", "classsightx_1_1sdk_1_1CefMetadataRendererStartStreamConfiguration_1_1Normalization.html#ae215c84267eb9002f3ee92872b3b52b2", null ],
    [ "getAlpha", "classsightx_1_1sdk_1_1CefMetadataRendererStartStreamConfiguration_1_1Normalization.html#a8640fda64f5b277d0add1376782b9a10", null ],
    [ "getBeta", "classsightx_1_1sdk_1_1CefMetadataRendererStartStreamConfiguration_1_1Normalization.html#ada49028193d06da37456d039ebaaf393", null ],
    [ "getStdCropSize", "classsightx_1_1sdk_1_1CefMetadataRendererStartStreamConfiguration_1_1Normalization.html#a071a7eabfa79cada9c6fd9cc9d58f185", null ],
    [ "getType", "classsightx_1_1sdk_1_1CefMetadataRendererStartStreamConfiguration_1_1Normalization.html#a6d1cf487c388e9cb9ea6d8856dc77b59", null ],
    [ "maxAlpha", "classsightx_1_1sdk_1_1CefMetadataRendererStartStreamConfiguration_1_1Normalization.html#a38c8b1340bf28205316379b1a61e8ebe", null ],
    [ "maxBeta", "classsightx_1_1sdk_1_1CefMetadataRendererStartStreamConfiguration_1_1Normalization.html#a79076aad79eb8fc147d68e1a1236180d", null ],
    [ "maxStdCropSize", "classsightx_1_1sdk_1_1CefMetadataRendererStartStreamConfiguration_1_1Normalization.html#a3cc995bbfad5e8bcbbe0b036d0c5dc3c", null ],
    [ "minAlpha", "classsightx_1_1sdk_1_1CefMetadataRendererStartStreamConfiguration_1_1Normalization.html#a24db6c1a56f524cee625701a0b382673", null ],
    [ "minBeta", "classsightx_1_1sdk_1_1CefMetadataRendererStartStreamConfiguration_1_1Normalization.html#a9bf873732fbb1eff511109981be49a07", null ],
    [ "minStdCropSize", "classsightx_1_1sdk_1_1CefMetadataRendererStartStreamConfiguration_1_1Normalization.html#a941f31fe3ed1e9cae827d438074fe746", null ],
    [ "operator=", "classsightx_1_1sdk_1_1CefMetadataRendererStartStreamConfiguration_1_1Normalization.html#a988533bb2888133d1deee33a0d55adc3", null ],
    [ "setAlpha", "classsightx_1_1sdk_1_1CefMetadataRendererStartStreamConfiguration_1_1Normalization.html#a4ee2580013ab502987d9e9b72dc6922a", null ],
    [ "setBeta", "classsightx_1_1sdk_1_1CefMetadataRendererStartStreamConfiguration_1_1Normalization.html#a7e27b79d3cea198c03e0559537414a37", null ],
    [ "setStdCropSize", "classsightx_1_1sdk_1_1CefMetadataRendererStartStreamConfiguration_1_1Normalization.html#a651a3351857f63042dacd82b7a288ba0", null ],
    [ "setType", "classsightx_1_1sdk_1_1CefMetadataRendererStartStreamConfiguration_1_1Normalization.html#a23b7429951368e5d69f65a2f2596eb53", null ]
];