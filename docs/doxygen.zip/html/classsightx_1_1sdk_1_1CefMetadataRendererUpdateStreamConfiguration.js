var classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration =
[
    [ "Normalization", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization.html", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization" ],
    [ "CefMetadataRendererUpdateStreamConfiguration", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration.html#af5c14276cfb19c8bad5840116836030c", null ],
    [ "CefMetadataRendererUpdateStreamConfiguration", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration.html#adf3093d4efb0b597c659285528dbb9b2", null ],
    [ "CefMetadataRendererUpdateStreamConfiguration", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration.html#af679f1b4219f0f6163b42e47563ff50f", null ],
    [ "~CefMetadataRendererUpdateStreamConfiguration", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration.html#a79674ed4de9799a016261714f3709d3d", null ],
    [ "getBrowserFrameRate", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration.html#a177f168d9dc3dc68e4c0461e94f644e1", null ],
    [ "getNormalization", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration.html#ad7ae958fd13209ceeae1df04986aec4c", null ],
    [ "getTargetHeight", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration.html#ae3cf4f9db0757cd5bbc43a2e297458fc", null ],
    [ "getTargetWidth", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration.html#a08672d894c89bdd1e4e753faa0646ac8", null ],
    [ "maxBrowserFrameRate", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration.html#a34afe899d728071a8d5dda890ec89305", null ],
    [ "maxTargetHeight", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration.html#ae30d7a19a6e171f1183e0ef9dc5693aa", null ],
    [ "maxTargetWidth", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration.html#ad90dcf42d9071f35824e06e8cc865dc4", null ],
    [ "minBrowserFrameRate", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration.html#a3ae4bd7543858ab7b7a3672085ebc592", null ],
    [ "minTargetHeight", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration.html#a16cc2b3117a30545afbc4e88132bbad0", null ],
    [ "minTargetWidth", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration.html#a314515767714cd1e7b7a77caa730b9da", null ],
    [ "operator=", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration.html#a044515f221455a7b7592bb231b95dd5e", null ],
    [ "setBrowserFrameRate", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration.html#a364de364d7d0f2395cccf9cb5c0ded61", null ],
    [ "setTargetHeight", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration.html#a5f54e69895d3d5a317ac14f1fe5527ab", null ],
    [ "setTargetWidth", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration.html#a8eaa08447c14630737402e9d20acde53", null ]
];