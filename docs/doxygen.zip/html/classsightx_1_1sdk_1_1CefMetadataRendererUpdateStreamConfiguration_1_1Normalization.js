var classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization =
[
    [ "Normalization", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#ae4a647afe45cb9cc17491ed84ef0d1cc", null ],
    [ "Normalization", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a9e9a5fe9094a7238a8748a8e7863a061", null ],
    [ "Normalization", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#ab01df50493f4dba7c25e0bee29cb9043", null ],
    [ "~Normalization", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a234574cdd4664395e3648f1dbfa846dd", null ],
    [ "getAlpha", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a02107a58b5841f41a250b07de7b4d060", null ],
    [ "getBeta", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a0bf0c06f9cb63c6bb3fcca010ff9b2a8", null ],
    [ "getStdCropSize", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a44fc55a1e78b1947cd8f4488298c998a", null ],
    [ "getType", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#afc24725fd114457e1cf86a7ef1ae03fe", null ],
    [ "maxAlpha", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a8eb5e27b7206aecdf4729f8d0ee0b2b9", null ],
    [ "maxBeta", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a6d1fa970c3610dda6ed95eec75d467e1", null ],
    [ "maxStdCropSize", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#ad0497f8eda1b7de6fe8eb6f185403c96", null ],
    [ "minAlpha", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a869bd25418873d4debbfa05a8daa06e8", null ],
    [ "minBeta", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a7ecda581c6c89882e69530f568db4b4d", null ],
    [ "minStdCropSize", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#aac3765261123035a618838f4e8d62593", null ],
    [ "operator=", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a9ade704d64d283e96bf55f8b077c0d3e", null ],
    [ "setAlpha", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#aba17b789ea6cb835633fb038e02c00a1", null ],
    [ "setBeta", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#ab8b99e73851b8f7b38be89b26be6e502", null ],
    [ "setStdCropSize", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a2328b95a4e08b9d621a1a7e18708dac6", null ],
    [ "setType", "classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a0c4c1a72467d2728bcf84ed744fa3943", null ]
];