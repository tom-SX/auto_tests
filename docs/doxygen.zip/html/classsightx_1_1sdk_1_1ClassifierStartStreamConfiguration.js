var classsightx_1_1sdk_1_1ClassifierStartStreamConfiguration =
[
    [ "AdjustCropInPercentsOverride", "classsightx_1_1sdk_1_1ClassifierStartStreamConfiguration_1_1AdjustCropInPercentsOverride.html", "classsightx_1_1sdk_1_1ClassifierStartStreamConfiguration_1_1AdjustCropInPercentsOverride" ],
    [ "Filter", "classsightx_1_1sdk_1_1ClassifierStartStreamConfiguration_1_1Filter.html", "classsightx_1_1sdk_1_1ClassifierStartStreamConfiguration_1_1Filter" ],
    [ "ClassifierStartStreamConfiguration", "classsightx_1_1sdk_1_1ClassifierStartStreamConfiguration.html#a896e8c1e727fcf6f45782e7e4206bb8c", null ],
    [ "ClassifierStartStreamConfiguration", "classsightx_1_1sdk_1_1ClassifierStartStreamConfiguration.html#afedef43d1a09d7d94666218224ced071", null ],
    [ "ClassifierStartStreamConfiguration", "classsightx_1_1sdk_1_1ClassifierStartStreamConfiguration.html#a5a7f6f570423f888b9377ec703ba52c7", null ],
    [ "~ClassifierStartStreamConfiguration", "classsightx_1_1sdk_1_1ClassifierStartStreamConfiguration.html#ae075a1a23fcd528df2ad6c4a635aca7b", null ],
    [ "clearScoreThresholds", "classsightx_1_1sdk_1_1ClassifierStartStreamConfiguration.html#ac51fd129afc19b6383e3e086e852d9e7", null ],
    [ "getAdjustCropInPercentsOverride", "classsightx_1_1sdk_1_1ClassifierStartStreamConfiguration.html#a207f92b96fc1eba42aac5671964b324c", null ],
    [ "getEnable", "classsightx_1_1sdk_1_1ClassifierStartStreamConfiguration.html#a0a054e0356eedf449efe0400c57a8258", null ],
    [ "getFilter", "classsightx_1_1sdk_1_1ClassifierStartStreamConfiguration.html#a6bbb761d52c8bbb3a580ea169307670c", null ],
    [ "getScoreThresholds", "classsightx_1_1sdk_1_1ClassifierStartStreamConfiguration.html#ad88d205853d8ef71b7ab557101022ba1", null ],
    [ "insertScoreThresholds", "classsightx_1_1sdk_1_1ClassifierStartStreamConfiguration.html#ae850b8ce185ba0a9a8c99aed2f064b4e", null ],
    [ "keysScoreThresholds", "classsightx_1_1sdk_1_1ClassifierStartStreamConfiguration.html#a985d39b1c6f2c3192a62c680f25181d0", null ],
    [ "maxScoreThresholds", "classsightx_1_1sdk_1_1ClassifierStartStreamConfiguration.html#a86361f7630d32d2b9b7267bd7519ce24", null ],
    [ "minScoreThresholds", "classsightx_1_1sdk_1_1ClassifierStartStreamConfiguration.html#aafbc5e8c13bf9aec1a4c2af4bf2d5ad4", null ],
    [ "operator=", "classsightx_1_1sdk_1_1ClassifierStartStreamConfiguration.html#a51251a8b2608788e3ce06b420f8611c5", null ],
    [ "setEnable", "classsightx_1_1sdk_1_1ClassifierStartStreamConfiguration.html#af1983e8869006df00ee3f3a3b1e3bab5", null ]
];