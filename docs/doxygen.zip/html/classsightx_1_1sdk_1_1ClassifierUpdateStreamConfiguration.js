var classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration =
[
    [ "AdjustCropInPercentsOverride", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration_1_1AdjustCropInPercentsOverride.html", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration_1_1AdjustCropInPercentsOverride" ],
    [ "Filter", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration_1_1Filter.html", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration_1_1Filter" ],
    [ "ClassifierUpdateStreamConfiguration", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration.html#a9322cd38078df3bfcf299927f1a37c0f", null ],
    [ "ClassifierUpdateStreamConfiguration", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration.html#a9311849bd5d3467242dacf6b175cc1c1", null ],
    [ "ClassifierUpdateStreamConfiguration", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration.html#ad5618581d5ca6b80e7e3e67487edaac3", null ],
    [ "~ClassifierUpdateStreamConfiguration", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration.html#a1b729e37b80ee22f9b08af48c7c49e1e", null ],
    [ "clearScoreThresholds", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration.html#a5f129f5fe78f2129a52eef0672dba14f", null ],
    [ "getAdjustCropInPercentsOverride", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration.html#a71bd96b76e7d0fe7da9d589bf0e54bc3", null ],
    [ "getEnable", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration.html#acbdd2ee0fcc3dab9079838b97d1f62fd", null ],
    [ "getFilter", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration.html#a0f35bfedb0ef121971264b056da9208f", null ],
    [ "getScoreThresholds", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration.html#ac32eed243b4092d2799159dad3a80309", null ],
    [ "insertScoreThresholds", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration.html#ab61a095b61e70951085cfcd417e0afe6", null ],
    [ "keysScoreThresholds", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration.html#ab78b5cc87af4a1124b8335106f627781", null ],
    [ "maxScoreThresholds", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration.html#a0ad3a272772657ecb5018987098957d4", null ],
    [ "minScoreThresholds", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration.html#acfd52324b5837a06752a83935339d59a", null ],
    [ "operator=", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration.html#a27a45fa354a9c4f797b8599557ca0b45", null ],
    [ "setEnable", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration.html#a8e7249363d0358ebb7ab906e83a8f02c", null ]
];