var classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration_1_1AdjustCropInPercentsOverride =
[
    [ "AdjustCropInPercentsOverride", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration_1_1AdjustCropInPercentsOverride.html#af3e277ec279f8caae2533ba5d6e82622", null ],
    [ "AdjustCropInPercentsOverride", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration_1_1AdjustCropInPercentsOverride.html#a7c24adc81b46a192be5e6135eeaa71b9", null ],
    [ "AdjustCropInPercentsOverride", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration_1_1AdjustCropInPercentsOverride.html#a20dff600118001c9187db7103639f0f9", null ],
    [ "~AdjustCropInPercentsOverride", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration_1_1AdjustCropInPercentsOverride.html#a5c3ab95da1b4df022ba5a001db870a2d", null ],
    [ "getHeight", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration_1_1AdjustCropInPercentsOverride.html#a79a1038de24be71902913d24ffe0bd34", null ],
    [ "getWidth", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration_1_1AdjustCropInPercentsOverride.html#a67556edb3391cc1ce52126f2e1b41b2d", null ],
    [ "maxHeight", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration_1_1AdjustCropInPercentsOverride.html#a57dec0d7877e98924d6065b702335255", null ],
    [ "maxWidth", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration_1_1AdjustCropInPercentsOverride.html#a729fb7c42191a2972d68179f0d666360", null ],
    [ "minHeight", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration_1_1AdjustCropInPercentsOverride.html#a9529d7f30bf604dc98dd38d1bdb6115b", null ],
    [ "minWidth", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration_1_1AdjustCropInPercentsOverride.html#ab6f8b79e9bc4b04bd914ddebed768184", null ],
    [ "operator=", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration_1_1AdjustCropInPercentsOverride.html#a7c1040bd582e79aba0ae71bcbc3f3476", null ],
    [ "setHeight", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration_1_1AdjustCropInPercentsOverride.html#a47fbe7927ba32471484344a40063569b", null ],
    [ "setWidth", "classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration_1_1AdjustCropInPercentsOverride.html#a82f225b32f205ca5d0600fe6a841c3e9", null ]
];