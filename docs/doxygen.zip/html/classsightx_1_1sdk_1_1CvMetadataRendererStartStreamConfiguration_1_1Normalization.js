var classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Normalization =
[
    [ "Normalization", "classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Normalization.html#aa74489a9faa93ff7bf2738da4e50a2eb", null ],
    [ "Normalization", "classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Normalization.html#a85291c44f22b3224f8c650965388565b", null ],
    [ "Normalization", "classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Normalization.html#a581825e8e01b8a5f5b2b54c26d87bd45", null ],
    [ "~Normalization", "classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Normalization.html#a617d7238e0fcdf920b4069684237a786", null ],
    [ "getAlpha", "classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Normalization.html#a35fbc747ce8986ad6e660b92ae30732b", null ],
    [ "getBeta", "classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Normalization.html#a3d1331186e1deee106fe51fe0c785d16", null ],
    [ "getStdCropSize", "classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Normalization.html#aaeccb58d5f9aa7f7cfc1c4b6277fc17a", null ],
    [ "getType", "classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Normalization.html#a8ac9c0ffd646a301532007dcc3293215", null ],
    [ "maxAlpha", "classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Normalization.html#a3527ab155b78ad532255012bbb694654", null ],
    [ "maxBeta", "classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Normalization.html#a0dbf2b7a534a70794f1eaba9ed001ab0", null ],
    [ "maxStdCropSize", "classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Normalization.html#a690f32c9d60ee78d43b8fbec0883706f", null ],
    [ "minAlpha", "classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Normalization.html#a92e252c2a673e326faa90cad43a4aef1", null ],
    [ "minBeta", "classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Normalization.html#a8f398767c6842d109997dfb8106357ca", null ],
    [ "minStdCropSize", "classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Normalization.html#afcbaf34586bffcfe64008ae3e9838d0b", null ],
    [ "operator=", "classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Normalization.html#ae90aa20102f9faf8a71d676730b68a9c", null ],
    [ "setAlpha", "classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Normalization.html#a917e92b2399fe25bb5cd6f188e76c71f", null ],
    [ "setBeta", "classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Normalization.html#a3e2c3528d1584a396c9bc9651a17e58d", null ],
    [ "setStdCropSize", "classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Normalization.html#a2b609103a4e56e32a3e753800888c59d", null ],
    [ "setType", "classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Normalization.html#a6172691bb88a826d03c6e471ab95f52c", null ]
];