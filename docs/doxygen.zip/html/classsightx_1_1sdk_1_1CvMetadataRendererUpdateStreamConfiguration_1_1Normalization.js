var classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Normalization =
[
    [ "Normalization", "classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a13534022fef171ffa03e8b6c4e659123", null ],
    [ "Normalization", "classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a6b774a68444249557efb4cf69f15e00f", null ],
    [ "Normalization", "classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#ac8f8633619c0e2446607772d0cdf9116", null ],
    [ "~Normalization", "classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a371c8e61b9f9e916bce4bd8fb4e97df5", null ],
    [ "getAlpha", "classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a0ba1c011e16404181df34b78aa47bdbd", null ],
    [ "getBeta", "classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a73b861056a55c850513b4309b2aea4e8", null ],
    [ "getStdCropSize", "classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a309f155bea5af5e5a912ce9a2e6a8499", null ],
    [ "getType", "classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#afcf2743698ccbef363ae52c753a5d770", null ],
    [ "maxAlpha", "classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a2acc74fbbccc8a4c684a0c795917c09e", null ],
    [ "maxBeta", "classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a65aa52da86d43fdf82fdd82802cdc94a", null ],
    [ "maxStdCropSize", "classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#ab83abeefdeee9ba2535af1575cd56550", null ],
    [ "minAlpha", "classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a2402653e9c163777191fcdd2766dafbc", null ],
    [ "minBeta", "classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#ae18593657134dbe921bb4aa0a110b748", null ],
    [ "minStdCropSize", "classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#ac5b1390285587e6e7ffb792b993eb017", null ],
    [ "operator=", "classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a0b4e0f658e7f70cdcb578282a1f68b1a", null ],
    [ "setAlpha", "classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#ae4b4a7649fc36138e7aab9088c1d1e18", null ],
    [ "setBeta", "classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a8b1239085129061f8923204a04579b75", null ],
    [ "setStdCropSize", "classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#a5b6eb72873025087ed8882e33ba50798", null ],
    [ "setType", "classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Normalization.html#addf6caefc6196072294a5bad2dd9d06b", null ]
];