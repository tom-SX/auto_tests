var classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi =
[
    [ "Roi", "classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html#a85f4125923ebb72b88999b98e27ea06a", null ],
    [ "Roi", "classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html#ae6c4a7b27b0a48f69adf0b56fa3d15b7", null ],
    [ "Roi", "classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html#adbad85d494ec9f2cacce4adae449f391", null ],
    [ "~Roi", "classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html#aa608c64cb8fd4efc0a6629e93a4191a3", null ],
    [ "getHeight", "classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html#a9d45b2651949fa8ba3bde9eccfeaea42", null ],
    [ "getWidth", "classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html#a872303321b72393b194f14219004d44c", null ],
    [ "getX", "classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html#a39c78dbeba99d560e86d189d687faee4", null ],
    [ "getY", "classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html#a13c46260689fe166bc79bd8a1d028fc2", null ],
    [ "maxHeight", "classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html#a3d4d39e51f685b2082446b00cae486c5", null ],
    [ "maxWidth", "classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html#af31859f87437fd03a41499e83e64af2f", null ],
    [ "maxX", "classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html#aaecb7b2712b726dfefaf6d2b1f6d6213", null ],
    [ "maxY", "classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html#a18ccd03081e3cd8e4f6a55f88b160230", null ],
    [ "minHeight", "classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html#a2accf741b6092d96e7db4f68a6652794", null ],
    [ "minWidth", "classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html#a4bb42ffe83027ddae5ea733c53859e1b", null ],
    [ "minX", "classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html#af211440267000c4ea8f048eb818ed052", null ],
    [ "minY", "classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html#aa20ab49cabe392fa2b295ab413706aaf", null ],
    [ "operator=", "classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html#a7aab9226389e17bf14c0979338d7f632", null ],
    [ "setHeight", "classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html#a6a610b98e1cfa2f1caae2559ae5a488e", null ],
    [ "setWidth", "classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html#a3279cab3b29518e7da7372e53b48871b", null ],
    [ "setX", "classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html#a3d4e2bc18f0779ea98d2c34a108239f9", null ],
    [ "setY", "classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html#a380fb9b4db8084372d9a4e8f551fc2ce", null ]
];