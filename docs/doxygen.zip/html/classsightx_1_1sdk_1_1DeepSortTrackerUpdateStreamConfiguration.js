var classsightx_1_1sdk_1_1DeepSortTrackerUpdateStreamConfiguration =
[
    [ "DeepSortTrackerUpdateStreamConfiguration", "classsightx_1_1sdk_1_1DeepSortTrackerUpdateStreamConfiguration.html#af3aaf5ecf3152d42fea46de1cf99a643", null ],
    [ "DeepSortTrackerUpdateStreamConfiguration", "classsightx_1_1sdk_1_1DeepSortTrackerUpdateStreamConfiguration.html#a2adf380e9a197dfbae220efeba48b569", null ],
    [ "DeepSortTrackerUpdateStreamConfiguration", "classsightx_1_1sdk_1_1DeepSortTrackerUpdateStreamConfiguration.html#a04e24133870dcf4e6d738be669182ee4", null ],
    [ "~DeepSortTrackerUpdateStreamConfiguration", "classsightx_1_1sdk_1_1DeepSortTrackerUpdateStreamConfiguration.html#a00bc1a2fdd7dd1c60b36f0e599453b40", null ],
    [ "getEnable", "classsightx_1_1sdk_1_1DeepSortTrackerUpdateStreamConfiguration.html#a07e7dcb966bb294a8cb9a146bd7ddaeb", null ],
    [ "getMaxTimeSinceUpdateToReportMs", "classsightx_1_1sdk_1_1DeepSortTrackerUpdateStreamConfiguration.html#a97ea903ad505a713852061583aff51a1", null ],
    [ "maxMaxTimeSinceUpdateToReportMs", "classsightx_1_1sdk_1_1DeepSortTrackerUpdateStreamConfiguration.html#ade495cc7d54250d966f637936c9bfff5", null ],
    [ "minMaxTimeSinceUpdateToReportMs", "classsightx_1_1sdk_1_1DeepSortTrackerUpdateStreamConfiguration.html#abde6d27ebef09f89c867b9992432550f", null ],
    [ "operator=", "classsightx_1_1sdk_1_1DeepSortTrackerUpdateStreamConfiguration.html#a5272b899a33ff6669b620e28a5b7fb10", null ],
    [ "setEnable", "classsightx_1_1sdk_1_1DeepSortTrackerUpdateStreamConfiguration.html#ad5a1a56a9cf08f7374867a0fbaefaf66", null ],
    [ "setMaxTimeSinceUpdateToReportMs", "classsightx_1_1sdk_1_1DeepSortTrackerUpdateStreamConfiguration.html#a0c33086d761eeaecbd9a14f4225354ef", null ]
];