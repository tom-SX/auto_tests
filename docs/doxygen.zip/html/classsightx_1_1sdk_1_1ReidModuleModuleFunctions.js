var classsightx_1_1sdk_1_1ReidModuleModuleFunctions =
[
    [ "ReidModuleModuleFunctions", "classsightx_1_1sdk_1_1ReidModuleModuleFunctions.html#a0532a4bc41ebb896eccfde50d2196800", null ],
    [ "AddGalleriesFeatures", "classsightx_1_1sdk_1_1ReidModuleModuleFunctions.html#a2b17c8dede950b3f97eb58486920ccbb", null ],
    [ "GetFeatures", "classsightx_1_1sdk_1_1ReidModuleModuleFunctions.html#aa2f930e94150e1c68d5c4696daf07147", null ],
    [ "GetGalleriesTracks", "classsightx_1_1sdk_1_1ReidModuleModuleFunctions.html#a89593c397c18eee3d2449ba9dc3900c4", null ],
    [ "MarkTracksForGallery", "classsightx_1_1sdk_1_1ReidModuleModuleFunctions.html#a0f2e452b4eaeb99a0996542b800f5252", null ],
    [ "RemoveTracksFromGallery", "classsightx_1_1sdk_1_1ReidModuleModuleFunctions.html#ab56865a7ea78597981392a08e535d7f0", null ],
    [ "UnmarkTracksForGallery", "classsightx_1_1sdk_1_1ReidModuleModuleFunctions.html#aae02c1e00b457be8a024018b9ab0a0e7", null ]
];