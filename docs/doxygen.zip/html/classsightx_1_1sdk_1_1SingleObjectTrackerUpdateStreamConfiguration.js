var classsightx_1_1sdk_1_1SingleObjectTrackerUpdateStreamConfiguration =
[
    [ "SingleObjectTrackerUpdateStreamConfiguration", "classsightx_1_1sdk_1_1SingleObjectTrackerUpdateStreamConfiguration.html#a79a275e72713a8544d617a4fcaaf5d92", null ],
    [ "SingleObjectTrackerUpdateStreamConfiguration", "classsightx_1_1sdk_1_1SingleObjectTrackerUpdateStreamConfiguration.html#a3b74da9e4a00f9867d1f93ef7fd8932a", null ],
    [ "SingleObjectTrackerUpdateStreamConfiguration", "classsightx_1_1sdk_1_1SingleObjectTrackerUpdateStreamConfiguration.html#a2010bd6909fb754d2ebca281bfc2a27e", null ],
    [ "~SingleObjectTrackerUpdateStreamConfiguration", "classsightx_1_1sdk_1_1SingleObjectTrackerUpdateStreamConfiguration.html#a6830c64f9aa6fa93876cfedf4c123ef5", null ],
    [ "getEnable", "classsightx_1_1sdk_1_1SingleObjectTrackerUpdateStreamConfiguration.html#a96239df707f3edc18a889d0a65d9de98", null ],
    [ "getUpdateScoreThreshold", "classsightx_1_1sdk_1_1SingleObjectTrackerUpdateStreamConfiguration.html#ae455a1e483fd4b28d504e649d2b73dfb", null ],
    [ "maxUpdateScoreThreshold", "classsightx_1_1sdk_1_1SingleObjectTrackerUpdateStreamConfiguration.html#a231116432d11dfdb4ddba342f7455e4f", null ],
    [ "minUpdateScoreThreshold", "classsightx_1_1sdk_1_1SingleObjectTrackerUpdateStreamConfiguration.html#a019f915eb2742673f60dc374c2e47ebe", null ],
    [ "operator=", "classsightx_1_1sdk_1_1SingleObjectTrackerUpdateStreamConfiguration.html#aa7ecafda54ea75281faa7d26c36cb066", null ],
    [ "setEnable", "classsightx_1_1sdk_1_1SingleObjectTrackerUpdateStreamConfiguration.html#af8138852e3ea847a4501d2b2bbf53c36", null ],
    [ "setUpdateScoreThreshold", "classsightx_1_1sdk_1_1SingleObjectTrackerUpdateStreamConfiguration.html#afb3e3fc774489d5628f43abeb1415150", null ]
];