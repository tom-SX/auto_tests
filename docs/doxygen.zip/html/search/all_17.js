var searchData=
[
  ['warning_730',['Warning',['../namespacesightx_1_1sdk.html#ad6da1f54f8f0b277a041add86dbd1015a0eaadb4fcb48a0a0ed7bc9868be9fbaa',1,'sightx::sdk']]],
  ['width_731',['Width',['../structsightx_1_1sdk_1_1Crop.html#a97b13ad0cbb0339188e09a82fa3b063e',1,'sightx::sdk::Crop::Width()'],['../structsightx_1_1sdk_1_1StreamInfo.html#a6088e8627705b3664b3cc1e1b788a3c0',1,'sightx::sdk::StreamInfo::Width()']]],
  ['wrapstream_732',['wrapStream',['../classsightx_1_1sdk_1_1Pipeline.html#aed2def3d15fd670a441e5c93d3ad774f',1,'sightx::sdk::Pipeline']]]
];
