var searchData=
[
  ['jpeg_312',['Jpeg',['../namespacesightx_1_1sdk.html#a73617026c7e93720b9e427c9b2cf5755a5023eac1d7fffa77b37c0e6797c97773',1,'sightx::sdk']]]
];
