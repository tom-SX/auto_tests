var searchData=
[
  ['adjustcropinpercentsoverride_804',['AdjustCropInPercentsOverride',['../classsightx_1_1sdk_1_1ClassifierStartStreamConfiguration_1_1AdjustCropInPercentsOverride.html',1,'sightx::sdk::ClassifierStartStreamConfiguration::AdjustCropInPercentsOverride'],['../classsightx_1_1sdk_1_1ClassifierUpdateStreamConfiguration_1_1AdjustCropInPercentsOverride.html',1,'sightx::sdk::ClassifierUpdateStreamConfiguration::AdjustCropInPercentsOverride']]],
  ['attribute_805',['Attribute',['../structsightx_1_1sdk_1_1Attribute.html',1,'sightx::sdk']]],
  ['attributegroups_806',['AttributeGroups',['../classsightx_1_1sdk_1_1DetectorUpdateStreamConfiguration_1_1Groups_1_1AttributeGroups.html',1,'sightx::sdk::DetectorUpdateStreamConfiguration::Groups::AttributeGroups'],['../classsightx_1_1sdk_1_1DetectorStartStreamConfiguration_1_1Groups_1_1AttributeGroups.html',1,'sightx::sdk::DetectorStartStreamConfiguration::Groups::AttributeGroups']]]
];
