var searchData=
[
  ['boundingbox_807',['BoundingBox',['../structsightx_1_1sdk_1_1BoundingBox.html',1,'sightx::sdk']]],
  ['boundingboxes_808',['BoundingBoxes',['../classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1BoundingBoxes.html',1,'sightx::sdk::CvMetadataRendererStartStreamConfiguration::BoundingBoxes'],['../classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1BoundingBoxes.html',1,'sightx::sdk::CvMetadataRendererUpdateStreamConfiguration::BoundingBoxes']]]
];
