var searchData=
[
  ['edgeinfo_833',['EdgeInfo',['../structsightx_1_1sdk_1_1EdgeInfo.html',1,'sightx::sdk']]]
];
