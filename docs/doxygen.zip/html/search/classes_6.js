var searchData=
[
  ['gcparameters_843',['GcParameters',['../classsightx_1_1sdk_1_1GcSourceStartStreamConfiguration_1_1GcParameters.html',1,'sightx::sdk::GcSourceStartStreamConfiguration']]],
  ['gcsourcestartstreamconfiguration_844',['GcSourceStartStreamConfiguration',['../classsightx_1_1sdk_1_1GcSourceStartStreamConfiguration.html',1,'sightx::sdk']]],
  ['groups_845',['Groups',['../classsightx_1_1sdk_1_1DetectorUpdateStreamConfiguration_1_1Groups.html',1,'sightx::sdk::DetectorUpdateStreamConfiguration::Groups'],['../classsightx_1_1sdk_1_1DetectorStartStreamConfiguration_1_1Groups.html',1,'sightx::sdk::DetectorStartStreamConfiguration::Groups']]],
  ['grpcsettings_846',['GrpcSettings',['../structsightx_1_1sdk_1_1GrpcSettings.html',1,'sightx::sdk']]],
  ['gstsinkstartstreamconfiguration_847',['GstSinkStartStreamConfiguration',['../classsightx_1_1sdk_1_1GstSinkStartStreamConfiguration.html',1,'sightx::sdk']]],
  ['gstsourcestartstreamconfiguration_848',['GstSourceStartStreamConfiguration',['../classsightx_1_1sdk_1_1GstSourceStartStreamConfiguration.html',1,'sightx::sdk']]]
];
