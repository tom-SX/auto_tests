var searchData=
[
  ['histogram_849',['Histogram',['../classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Histogram.html',1,'sightx::sdk::CvMetadataRendererUpdateStreamConfiguration::Histogram'],['../classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Histogram.html',1,'sightx::sdk::CvMetadataRendererStartStreamConfiguration::Histogram']]]
];
