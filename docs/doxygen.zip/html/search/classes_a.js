var searchData=
[
  ['normalization_859',['Normalization',['../classsightx_1_1sdk_1_1CefMetadataRendererStartStreamConfiguration_1_1Normalization.html',1,'sightx::sdk::CefMetadataRendererStartStreamConfiguration::Normalization'],['../classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Normalization.html',1,'sightx::sdk::CvMetadataRendererStartStreamConfiguration::Normalization'],['../classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Normalization.html',1,'sightx::sdk::CvMetadataRendererUpdateStreamConfiguration::Normalization'],['../classsightx_1_1sdk_1_1CefMetadataRendererUpdateStreamConfiguration_1_1Normalization.html',1,'sightx::sdk::CefMetadataRendererUpdateStreamConfiguration::Normalization']]]
];
