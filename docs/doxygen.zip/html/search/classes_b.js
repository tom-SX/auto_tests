var searchData=
[
  ['osd_860',['Osd',['../classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1Osd.html',1,'sightx::sdk::CvMetadataRendererStartStreamConfiguration::Osd'],['../classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1Osd.html',1,'sightx::sdk::CvMetadataRendererUpdateStreamConfiguration::Osd']]]
];
