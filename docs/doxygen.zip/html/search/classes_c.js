var searchData=
[
  ['pipeline_861',['Pipeline',['../classsightx_1_1sdk_1_1Pipeline.html',1,'sightx::sdk']]],
  ['pipelineinfo_862',['PipelineInfo',['../structsightx_1_1sdk_1_1PipelineInfo.html',1,'sightx::sdk']]],
  ['point_863',['Point',['../structsightx_1_1sdk_1_1Point.html',1,'sightx::sdk']]]
];
