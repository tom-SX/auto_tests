var searchData=
[
  ['rawsourcestartstreamconfiguration_864',['RawSourceStartStreamConfiguration',['../classsightx_1_1sdk_1_1RawSourceStartStreamConfiguration.html',1,'sightx::sdk']]],
  ['rawstreamsettings_865',['RawStreamSettings',['../structsightx_1_1sdk_1_1RawStreamSettings.html',1,'sightx::sdk']]],
  ['reidhotcold_866',['ReidHotCold',['../classsightx_1_1sdk_1_1CvMetadataRendererStartStreamConfiguration_1_1ReidHotCold.html',1,'sightx::sdk::CvMetadataRendererStartStreamConfiguration::ReidHotCold'],['../classsightx_1_1sdk_1_1CvMetadataRendererUpdateStreamConfiguration_1_1ReidHotCold.html',1,'sightx::sdk::CvMetadataRendererUpdateStreamConfiguration::ReidHotCold']]],
  ['reidmodulemodulefunctions_867',['ReidModuleModuleFunctions',['../classsightx_1_1sdk_1_1ReidModuleModuleFunctions.html',1,'sightx::sdk']]],
  ['reidmodulestartstreamconfiguration_868',['ReidModuleStartStreamConfiguration',['../classsightx_1_1sdk_1_1ReidModuleStartStreamConfiguration.html',1,'sightx::sdk']]],
  ['reidmoduleupdatestreamconfiguration_869',['ReidModuleUpdateStreamConfiguration',['../classsightx_1_1sdk_1_1ReidModuleUpdateStreamConfiguration.html',1,'sightx::sdk']]],
  ['roi_870',['Roi',['../classsightx_1_1sdk_1_1DetectorUpdateStreamConfiguration_1_1Roi.html',1,'sightx::sdk::DetectorUpdateStreamConfiguration::Roi'],['../classsightx_1_1sdk_1_1CvPreprocessorUpdateStreamConfiguration_1_1Roi.html',1,'sightx::sdk::CvPreprocessorUpdateStreamConfiguration::Roi'],['../classsightx_1_1sdk_1_1DetectorStartStreamConfiguration_1_1Roi.html',1,'sightx::sdk::DetectorStartStreamConfiguration::Roi'],['../classsightx_1_1sdk_1_1CvPreprocessorStartStreamConfiguration_1_1Roi.html',1,'sightx::sdk::CvPreprocessorStartStreamConfiguration::Roi']]]
];
