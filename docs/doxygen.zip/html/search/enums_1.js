var searchData=
[
  ['datatype_1616',['DataType',['../namespacesightx_1_1sdk.html#a2cb25755155deabf0a56cbcd34d0911e',1,'sightx::sdk']]],
  ['deviceaccess_1617',['DeviceAccess',['../namespacesightx_1_1sdk.html#a19fd3bd1c06add0b19d0781c877a4dc3',1,'sightx::sdk']]]
];
