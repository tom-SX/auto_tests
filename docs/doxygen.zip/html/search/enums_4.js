var searchData=
[
  ['imagecompression_1620',['ImageCompression',['../namespacesightx_1_1sdk.html#a73617026c7e93720b9e427c9b2cf5755',1,'sightx::sdk']]]
];
