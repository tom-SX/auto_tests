var searchData=
[
  ['normalizationtype_1623',['NormalizationType',['../namespacesightx_1_1sdk.html#ae493e648c2408c2d6badfbe28cec301d',1,'sightx::sdk']]]
];
