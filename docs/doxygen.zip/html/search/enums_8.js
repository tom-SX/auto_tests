var searchData=
[
  ['osdvalue_1624',['OsdValue',['../namespacesightx_1_1sdk.html#a2e6a8a2dc0eb3f9a9ee6b7df0ed13dfc',1,'sightx::sdk']]]
];
