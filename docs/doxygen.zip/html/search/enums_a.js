var searchData=
[
  ['rawsourceid_1632',['RawSourceId',['../namespacesightx_1_1sdk.html#afa223254b4838ddce079f078b6420794',1,'sightx::sdk']]],
  ['rawsourcemode_1633',['RawSourceMode',['../namespacesightx_1_1sdk.html#a5cad5c6899f312f00ede564f7954af5e',1,'sightx::sdk']]],
  ['reidmode_1634',['ReidMode',['../namespacesightx_1_1sdk.html#aea51ec986b64912186d6cef8e9aeacaa',1,'sightx::sdk']]]
];
