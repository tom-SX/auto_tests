var searchData=
[
  ['debug_1645',['Debug',['../namespacesightx_1_1sdk.html#ad6da1f54f8f0b277a041add86dbd1015aa603905470e2a5b8c13e96b579ef0dba',1,'sightx::sdk']]]
];
