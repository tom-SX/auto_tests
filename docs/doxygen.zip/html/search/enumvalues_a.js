var searchData=
[
  ['serverdown_1661',['ServerDown',['../namespacesightx_1_1sdk.html#a2eb9f1db6c34ebde42e4cd0d4dba72cba90c6effd211397d23ebe2fc216823947',1,'sightx::sdk']]],
  ['serverup_1662',['ServerUp',['../namespacesightx_1_1sdk.html#a2eb9f1db6c34ebde42e4cd0d4dba72cba975b90f7fd8893c83cdafaeb4ff3a262',1,'sightx::sdk']]],
  ['started_1663',['Started',['../namespacesightx_1_1sdk.html#aebdd29ff89a8ae23fc09e054c2709c8da8428552d86c0d262a542a528af490afa',1,'sightx::sdk']]],
  ['stopped_1664',['Stopped',['../namespacesightx_1_1sdk.html#aebdd29ff89a8ae23fc09e054c2709c8dac23e2b09ebe6bf4cb5e2a9abe85c0be2',1,'sightx::sdk']]]
];
