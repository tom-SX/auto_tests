var searchData=
[
  ['terminated_1665',['Terminated',['../namespacesightx_1_1sdk.html#aebdd29ff89a8ae23fc09e054c2709c8dafba9c4daa2dd29d1077d32d965320ac1',1,'sightx::sdk']]]
];
