var searchData=
[
  ['warning_1667',['Warning',['../namespacesightx_1_1sdk.html#ad6da1f54f8f0b277a041add86dbd1015a0eaadb4fcb48a0a0ed7bc9868be9fbaa',1,'sightx::sdk']]]
];
