var searchData=
[
  ['_5fgetdata_909',['_getData',['../classsightx_1_1sdk_1_1FullStreamConfiguration.html#ab41dd7bf1649efe47fa7f61e06336cc0',1,'sightx::sdk::FullStreamConfiguration::_getData()'],['../classsightx_1_1sdk_1_1StartStreamConfiguration.html#ac655c3746adbdb997bf21b22898bfa29',1,'sightx::sdk::StartStreamConfiguration::_getData()'],['../classsightx_1_1sdk_1_1UpdateStreamConfiguration.html#a213ef91681454e3abb1be3cda92592a7',1,'sightx::sdk::UpdateStreamConfiguration::_getData()']]]
];
