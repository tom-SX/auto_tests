var searchData=
[
  ['wrapstream_1430',['wrapStream',['../classsightx_1_1sdk_1_1Pipeline.html#aed2def3d15fd670a441e5c93d3ad774f',1,'sightx::sdk::Pipeline']]]
];
