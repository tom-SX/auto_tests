var searchData=
[
  ['processcrops_1287',['processCrops',['../classsightx_1_1sdk_1_1Stream.html#a03ef1f9a17a3ba61411d3548e490d7d9',1,'sightx::sdk::Stream']]],
  ['processsingleframe_1288',['processSingleFrame',['../classsightx_1_1sdk_1_1Stream.html#a8ce27cdce992bfe4228b53a5295c2231',1,'sightx::sdk::Stream']]],
  ['pushrawframe_1289',['pushRawFrame',['../classsightx_1_1sdk_1_1Stream.html#acaa0b754e1c5aff5054167f71a0ee8aa',1,'sightx::sdk::Stream']]]
];
