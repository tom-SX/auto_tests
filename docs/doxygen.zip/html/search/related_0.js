var searchData=
[
  ['operator_3d_3d_1671',['operator==',['../classsightx_1_1sdk_1_1String.html#ac86de6fd03a4ac7d51a6ab0813d883d5',1,'sightx::sdk::String::operator==()'],['../classsightx_1_1sdk_1_1Vector.html#af3e875323562b5d2ed7149222759d1dc',1,'sightx::sdk::Vector::operator==()']]]
];
