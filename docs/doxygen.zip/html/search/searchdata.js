var indexSectionsWithContent =
{
  0: "_abcdefghijklmnopqrstuvwxy~",
  1: "abcdefghlmnoprstuv",
  2: "s",
  3: "_abcdfghiklmnoprstuvw~",
  4: "acdefghiklmnopqrstuvwxy",
  5: "fmrst",
  6: "cdfgiklnoprsv",
  7: "bcdegijnprstuwy",
  8: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends"
};

