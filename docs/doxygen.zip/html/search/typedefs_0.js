var searchData=
[
  ['frameresultscallback_1607',['FrameResultsCallback',['../namespacesightx_1_1sdk.html#ab380ea8927e13f50cd5c74290b661f02',1,'sightx::sdk']]]
];
