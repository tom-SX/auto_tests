var searchData=
[
  ['messagecallback_1608',['MessageCallback',['../namespacesightx_1_1sdk.html#a80e90d686d1854f85d8051f483bb0bcd',1,'sightx::sdk']]]
];
