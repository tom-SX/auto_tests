var searchData=
[
  ['serverstatecallback_1610',['ServerStateCallback',['../namespacesightx_1_1sdk.html#a0aacedb14122b5bd0258a09351c6c0a6',1,'sightx::sdk']]],
  ['streamcallback_1611',['StreamCallback',['../namespacesightx_1_1sdk.html#a69b0744c1d33d48273d0b30665e0090f',1,'sightx::sdk']]]
];
