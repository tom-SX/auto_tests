var searchData=
[
  ['trackidtype_1612',['TrackIdType',['../namespacesightx_1_1sdk.html#a61a67cf2e28727ed1fc15cbbfb1919f6',1,'sightx::sdk']]],
  ['type_1613',['Type',['../structsightx_1_1sdk_1_1SingleFrameOutputType.html#ae3b655ee10f27d8afe988d2bccf25737',1,'sightx::sdk::SingleFrameOutputType']]]
];
