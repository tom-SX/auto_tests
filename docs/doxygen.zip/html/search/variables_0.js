var searchData=
[
  ['active_1493',['Active',['../structsightx_1_1sdk_1_1ModuleInfo.html#a2fed645094dc0781bf139aa6231fb040',1,'sightx::sdk::ModuleInfo::Active()'],['../structsightx_1_1sdk_1_1EdgeInfo.html#a1b562e9c9b9ff04bb230397aaf027e3e',1,'sightx::sdk::EdgeInfo::Active()']]],
  ['allocated_1494',['Allocated',['../structsightx_1_1sdk_1_1MemoryAllocationInfo.html#ab4691e7d0bf93d320e94681b7011cfce',1,'sightx::sdk::MemoryAllocationInfo']]],
  ['allocationsrate_1495',['AllocationsRate',['../structsightx_1_1sdk_1_1MemoryAllocationInfo.html#a5275d64268f843cdb5ec79a69058c7e6',1,'sightx::sdk::MemoryAllocationInfo']]],
  ['altitudemeters_1496',['AltitudeMeters',['../structsightx_1_1sdk_1_1Track.html#ac8bce0f4bab7b193aa35df993c19b890',1,'sightx::sdk::Track']]],
  ['attributes_1497',['Attributes',['../structsightx_1_1sdk_1_1Track.html#a63cb862606e5b5088310663c8ee87b77',1,'sightx::sdk::Track::Attributes()'],['../structsightx_1_1sdk_1_1SingleFrameOutput.html#a95922275477681604e3b5c0ff4f87ff0',1,'sightx::sdk::SingleFrameOutput::Attributes()']]]
];
