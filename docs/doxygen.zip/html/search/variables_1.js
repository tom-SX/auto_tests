var searchData=
[
  ['cameraoffsetxmeters_1498',['CameraOffsetXMeters',['../structsightx_1_1sdk_1_1TelemetryInfo.html#a2ce0aa0f64cfc6a081a6974c57d9f9b6',1,'sightx::sdk::TelemetryInfo']]],
  ['cameraoffsetymeters_1499',['CameraOffsetYMeters',['../structsightx_1_1sdk_1_1TelemetryInfo.html#aa6e9c1d4b9e08e6880ef0514f08be350',1,'sightx::sdk::TelemetryInfo']]],
  ['cameraoffsetzmeters_1500',['CameraOffsetZMeters',['../structsightx_1_1sdk_1_1TelemetryInfo.html#ac1da1e366508284ef1f03fbddc480a42',1,'sightx::sdk::TelemetryInfo']]],
  ['camerapanworldmrads_1501',['CameraPanWorldMrads',['../structsightx_1_1sdk_1_1TelemetryInfo.html#ad6dc15c95a274f0a2e1f1033bcf42b78',1,'sightx::sdk::TelemetryInfo']]],
  ['camerarollworldmrads_1502',['CameraRollWorldMrads',['../structsightx_1_1sdk_1_1TelemetryInfo.html#a68767c5efaadf3597e8285d81a046af3',1,'sightx::sdk::TelemetryInfo']]],
  ['cameratiltworldmrads_1503',['CameraTiltWorldMrads',['../structsightx_1_1sdk_1_1TelemetryInfo.html#a12b92d89b59113340422c7c15a566dbf',1,'sightx::sdk::TelemetryInfo']]],
  ['class_1504',['Class',['../structsightx_1_1sdk_1_1Detection.html#a442e264e97d4c27bb34d3f93dbaf2422',1,'sightx::sdk::Detection']]],
  ['closed_1505',['Closed',['../structsightx_1_1sdk_1_1Track.html#ae807a62bc788fc721b803455d4ca846e',1,'sightx::sdk::Track']]],
  ['compatible_1506',['Compatible',['../structsightx_1_1sdk_1_1ServerInfo.html#a9bdc0035de31facaf32d861e348b8db1',1,'sightx::sdk::ServerInfo']]],
  ['compression_1507',['Compression',['../structsightx_1_1sdk_1_1RawStreamSettings.html#a38fe47d05d1df8db1fd32bda9b12725e',1,'sightx::sdk::RawStreamSettings']]]
];
