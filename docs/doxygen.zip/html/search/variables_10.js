var searchData=
[
  ['score_1572',['Score',['../structsightx_1_1sdk_1_1Detection.html#a6a1a668958fd8f1027bae7ceb88443d7',1,'sightx::sdk::Detection::Score()'],['../structsightx_1_1sdk_1_1Attribute.html#a2926a4870ca074a30a564b882e5ed6d3',1,'sightx::sdk::Attribute::Score()'],['../structsightx_1_1sdk_1_1Crop.html#aca0ad78d44800abf76122dbee86063cf',1,'sightx::sdk::Crop::Score()']]],
  ['serverip_1573',['ServerIP',['../structsightx_1_1sdk_1_1GrpcSettings.html#aa4ebd8e2fab86392668a775311b58609',1,'sightx::sdk::GrpcSettings']]],
  ['source_1574',['Source',['../structsightx_1_1sdk_1_1Track.html#ae0f0bc8bacb568b52e1fc700ad809ffb',1,'sightx::sdk::Track']]],
  ['state_1575',['State',['../structsightx_1_1sdk_1_1StreamInfo.html#a222cfef4172c68092e16c0a57d92e84e',1,'sightx::sdk::StreamInfo']]],
  ['statistics_1576',['Statistics',['../structsightx_1_1sdk_1_1ModuleInfo.html#a45ecee551fed9f5db8f4aa1da32d2395',1,'sightx::sdk::ModuleInfo']]],
  ['step_1577',['Step',['../structsightx_1_1sdk_1_1Crop.html#aac160a69930ec0aeb0c29fd95eb2abfd',1,'sightx::sdk::Crop']]],
  ['streamid_1578',['StreamId',['../structsightx_1_1sdk_1_1FrameResults.html#a847192549648188425f3bdbeba06f254',1,'sightx::sdk::FrameResults::StreamId()'],['../structsightx_1_1sdk_1_1StreamLog.html#ad129d26f2a6a0fb786d0ba8ff0bada06',1,'sightx::sdk::StreamLog::StreamId()']]],
  ['systemavailablestoragebytes_1579',['SystemAvailableStorageBytes',['../structsightx_1_1sdk_1_1UtilizationRates.html#a249cac5492faaa709baee9026d8f2ddb',1,'sightx::sdk::UtilizationRates']]],
  ['systemcpucores_1580',['SystemCpuCores',['../structsightx_1_1sdk_1_1UtilizationRates.html#afb443f41fc98acb30670f6a0ef3b3567',1,'sightx::sdk::UtilizationRates']]],
  ['systemcputemperature_1581',['SystemCpuTemperature',['../structsightx_1_1sdk_1_1UtilizationRates.html#a4e40126a273b8c15200fdf1b087d29e7',1,'sightx::sdk::UtilizationRates']]],
  ['systemfreememorybytes_1582',['SystemFreeMemoryBytes',['../structsightx_1_1sdk_1_1UtilizationRates.html#a50ce3a2dedd91c9bb1c1a92f1b56087e',1,'sightx::sdk::UtilizationRates']]],
  ['systemfreeswapbytes_1583',['SystemFreeSwapBytes',['../structsightx_1_1sdk_1_1UtilizationRates.html#a020cb4224d0d4fe90687791f9f582913',1,'sightx::sdk::UtilizationRates']]],
  ['systemtotalmemorybytes_1584',['SystemTotalMemoryBytes',['../structsightx_1_1sdk_1_1UtilizationRates.html#a877d3747e5abe8fc7cd2091f637b0080',1,'sightx::sdk::UtilizationRates']]],
  ['systemtotalstoragebytes_1585',['SystemTotalStorageBytes',['../structsightx_1_1sdk_1_1UtilizationRates.html#a858272767a2f7399b92d43d1c6561bc3',1,'sightx::sdk::UtilizationRates']]],
  ['systemtotalswapbytes_1586',['SystemTotalSwapBytes',['../structsightx_1_1sdk_1_1UtilizationRates.html#aa006ba7f0d55ab20a1bdc08084a6de4d',1,'sightx::sdk::UtilizationRates']]]
];
