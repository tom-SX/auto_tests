var searchData=
[
  ['text_1587',['Text',['../structsightx_1_1sdk_1_1MessageLog.html#a740fa2eaf2ff3154812500ea1de42cb6',1,'sightx::sdk::MessageLog::Text()'],['../structsightx_1_1sdk_1_1StreamLog.html#ad19b0644b2f773e09fdf77126c41ffa2',1,'sightx::sdk::StreamLog::Text()']]],
  ['timeoutinmsecs_1588',['TimeoutInMsecs',['../structsightx_1_1sdk_1_1GrpcSettings.html#a9c8acb4041247cafb356d1fe4ce8100c',1,'sightx::sdk::GrpcSettings']]],
  ['trackid_1589',['TrackId',['../structsightx_1_1sdk_1_1Track.html#a9f19df18a55e4a614fb925a67839f42a',1,'sightx::sdk::Track']]],
  ['tracks_1590',['Tracks',['../structsightx_1_1sdk_1_1FrameResults.html#a9289d781bf179541c1dfdeaf8736164d',1,'sightx::sdk::FrameResults']]],
  ['type_1591',['Type',['../structsightx_1_1sdk_1_1ModuleInfo.html#a5dffb969cd2ada21f33600464aed1597',1,'sightx::sdk::ModuleInfo']]]
];
