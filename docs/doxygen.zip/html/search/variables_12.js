var searchData=
[
  ['uninitializedoptional_1592',['UninitializedOptional',['../structsightx_1_1sdk_1_1TelemetryInfo.html#af47bab8e80ff2986dff488a29121626c',1,'sightx::sdk::TelemetryInfo']]],
  ['uninitializedrequired_1593',['UninitializedRequired',['../structsightx_1_1sdk_1_1TelemetryInfo.html#a07f8a38650243e89a7b1e22f808f9ca2',1,'sightx::sdk::TelemetryInfo']]],
  ['uptime_1594',['UpTime',['../structsightx_1_1sdk_1_1StreamInfo.html#af7879b5b3a082d92a1d614839daa5ebf',1,'sightx::sdk::StreamInfo::UpTime()'],['../structsightx_1_1sdk_1_1PipelineInfo.html#a7b20ef6e2f7bc5ce2d05d649b22aef71',1,'sightx::sdk::PipelineInfo::UpTime()']]],
  ['used_1595',['Used',['../structsightx_1_1sdk_1_1MemoryAllocationInfo.html#a5c8e1b1c26a07ed252f7abe77c0c3506',1,'sightx::sdk::MemoryAllocationInfo']]]
];
