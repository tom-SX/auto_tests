var searchData=
[
  ['value_1596',['Value',['../structsightx_1_1sdk_1_1Attribute.html#a16feda0a1b6b3db03df34fbc7189889d',1,'sightx::sdk::Attribute::Value()'],['../structsightx_1_1sdk_1_1ModuleStatistics.html#ac7a6ad9cb559a0a66652f1481cceca77',1,'sightx::sdk::ModuleStatistics::Value()']]],
  ['velocity_1597',['Velocity',['../structsightx_1_1sdk_1_1Track.html#ae3c5388f245f1b1e6ba08a48b90b9b8a',1,'sightx::sdk::Track']]],
  ['version_1598',['Version',['../structsightx_1_1sdk_1_1ServerInfo.html#a467f809e8457a4cf6ac7be3beeb3e63b',1,'sightx::sdk::ServerInfo']]],
  ['verticalfovmrads_1599',['VerticalFOVMrads',['../structsightx_1_1sdk_1_1TelemetryInfo.html#a8bcfeea5870f1293f99718859d0e6fee',1,'sightx::sdk::TelemetryInfo']]]
];
