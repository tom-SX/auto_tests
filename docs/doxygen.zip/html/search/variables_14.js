var searchData=
[
  ['width_1600',['Width',['../structsightx_1_1sdk_1_1Crop.html#a97b13ad0cbb0339188e09a82fa3b063e',1,'sightx::sdk::Crop::Width()'],['../structsightx_1_1sdk_1_1StreamInfo.html#a6088e8627705b3664b3cc1e1b788a3c0',1,'sightx::sdk::StreamInfo::Width()']]]
];
