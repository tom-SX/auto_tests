var searchData=
[
  ['data_1508',['Data',['../structsightx_1_1sdk_1_1SingleFrameOutputs.html#a631daa9db9f5d574916391b98a4f1c9b',1,'sightx::sdk::SingleFrameOutputs::Data()'],['../structsightx_1_1sdk_1_1Crop.html#aa49d504e9e06fad0d2a959df2dd852fd',1,'sightx::sdk::Crop::Data()']]],
  ['detectiondata_1509',['DetectionData',['../structsightx_1_1sdk_1_1Track.html#a13247bbb210fbf42d3266a0d030780b0',1,'sightx::sdk::Track::DetectionData()'],['../structsightx_1_1sdk_1_1SingleFrameOutput.html#a9361c6333b61a249bafaa0655a2ae768',1,'sightx::sdk::SingleFrameOutput::DetectionData()']]],
  ['detections_1510',['Detections',['../structsightx_1_1sdk_1_1SingleFrameOutputType.html#a8646a30baf19242250a54bece0f8999a',1,'sightx::sdk::SingleFrameOutputType']]],
  ['distanceinmeters_1511',['DistanceInMeters',['../structsightx_1_1sdk_1_1Track.html#acced6a7edc37a0eddd727eaeeb27e311',1,'sightx::sdk::Track']]],
  ['droppedframes_1512',['DroppedFrames',['../structsightx_1_1sdk_1_1ModuleInfo.html#a63a0c743b4ec875fb9a7e859ccbc1955',1,'sightx::sdk::ModuleInfo::DroppedFrames()'],['../structsightx_1_1sdk_1_1StreamInfo.html#a11e4c3f123c0a6ee7d4da65a5c876fe4',1,'sightx::sdk::StreamInfo::DroppedFrames()']]]
];
