var searchData=
[
  ['features_1516',['Features',['../structsightx_1_1sdk_1_1SingleFrameOutputType.html#afe96b7189125b9b51d91e00af02b6ad9',1,'sightx::sdk::SingleFrameOutputType::Features()'],['../structsightx_1_1sdk_1_1SingleFrameOutput.html#a3cd7a0030c0e3dbc0ae0542b9a3e536c',1,'sightx::sdk::SingleFrameOutput::Features()']]],
  ['format_1517',['Format',['../structsightx_1_1sdk_1_1Crop.html#a126905b17463b541c05208c28daa2616',1,'sightx::sdk::Crop']]],
  ['fps_1518',['FPS',['../structsightx_1_1sdk_1_1ModuleInfo.html#abf7c2e2aa7e11ddbb1ecc2f11c7eda4c',1,'sightx::sdk::ModuleInfo::FPS()'],['../structsightx_1_1sdk_1_1StreamInfo.html#a4fe8b4fd2f86882633ca287471e411e8',1,'sightx::sdk::StreamInfo::FPS()']]],
  ['frameid_1519',['FrameId',['../structsightx_1_1sdk_1_1FrameResults.html#ad8325d45b0b3bafcad03dfda3cb195d3',1,'sightx::sdk::FrameResults']]]
];
