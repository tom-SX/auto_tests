var searchData=
[
  ['gpufreememorybytes_1520',['GpuFreeMemoryBytes',['../structsightx_1_1sdk_1_1UtilizationRates.html#aa58e695184e113b282762467303b679c',1,'sightx::sdk::UtilizationRates']]],
  ['gpuload_1521',['GpuLoad',['../structsightx_1_1sdk_1_1UtilizationRates.html#aba0a57a1534b789fd63df3ff6f5cb414',1,'sightx::sdk::UtilizationRates']]],
  ['gpumemoryallocation_1522',['GpuMemoryAllocation',['../structsightx_1_1sdk_1_1PipelineInfo.html#a1699a230166ae5d17c20604ffc398bbf',1,'sightx::sdk::PipelineInfo']]],
  ['gputemperature_1523',['GpuTemperature',['../structsightx_1_1sdk_1_1UtilizationRates.html#a4f02e075b8ec0527187bd089b339d3b2',1,'sightx::sdk::UtilizationRates']]],
  ['gputotalmemorybytes_1524',['GpuTotalMemoryBytes',['../structsightx_1_1sdk_1_1UtilizationRates.html#af60c14858a0b525c548d88c02592e396',1,'sightx::sdk::UtilizationRates']]]
];
