var searchData=
[
  ['height_1525',['Height',['../structsightx_1_1sdk_1_1Crop.html#a8fab1808aeb2290b6fe3e62c81a7ebe2',1,'sightx::sdk::Crop::Height()'],['../structsightx_1_1sdk_1_1StreamInfo.html#acea1b5c069f605e20fdc3e48a29779eb',1,'sightx::sdk::StreamInfo::Height()']]],
  ['horizontalfovmrads_1526',['HorizontalFOVMrads',['../structsightx_1_1sdk_1_1TelemetryInfo.html#af2d4e735f83c60cedbd1938f08555693',1,'sightx::sdk::TelemetryInfo']]],
  ['hostname_1527',['HostName',['../structsightx_1_1sdk_1_1ServerInfo.html#a0120f9ad6f613c071118fdb331ebe442',1,'sightx::sdk::ServerInfo']]]
];
