var searchData=
[
  ['keepaliveperiodinmsecs_1531',['KeepAlivePeriodInMsecs',['../structsightx_1_1sdk_1_1GrpcSettings.html#a23101c290ec83586c37f08f335270b8f',1,'sightx::sdk::GrpcSettings']]]
];
