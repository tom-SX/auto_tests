var searchData=
[
  ['latencyms_1532',['LatencyMs',['../structsightx_1_1sdk_1_1FrameResults.html#a75249d2f8b4dd2486f97165a3d2b6749',1,'sightx::sdk::FrameResults::LatencyMs()'],['../structsightx_1_1sdk_1_1StreamInfo.html#a05a01759ab924714a0dfd56d81262839',1,'sightx::sdk::StreamInfo::LatencyMs()']]],
  ['latitudedegrees_1533',['LatitudeDegrees',['../structsightx_1_1sdk_1_1Track.html#a91dc3c6430fd8dfe89a43ee8d0df0d30',1,'sightx::sdk::Track']]],
  ['level_1534',['Level',['../structsightx_1_1sdk_1_1MessageLog.html#ac86929a31ad43f3a9473a084f448c9de',1,'sightx::sdk::MessageLog']]],
  ['limit_1535',['Limit',['../structsightx_1_1sdk_1_1MemoryAllocationInfo.html#a9cf3639c2af6115318cf5920c1b63ae5',1,'sightx::sdk::MemoryAllocationInfo']]],
  ['location_1536',['Location',['../structsightx_1_1sdk_1_1Detection.html#ada17c61e807797b89c8ccb1653e20cb9',1,'sightx::sdk::Detection']]],
  ['longitudedegrees_1537',['LongitudeDegrees',['../structsightx_1_1sdk_1_1Track.html#a8d2006472beec29e3e7177a01f2d8281',1,'sightx::sdk::Track']]]
];
