var searchData=
[
  ['markedforreidgallery_1538',['MarkedForReidGallery',['../structsightx_1_1sdk_1_1Track.html#a0d3f635ad34b1650bb654fd1c8eca931',1,'sightx::sdk::Track']]],
  ['maxqueuesize_1539',['MaxQueueSize',['../structsightx_1_1sdk_1_1ModuleInfo.html#a2c18e11cf655f821e4df48e433df66a4',1,'sightx::sdk::ModuleInfo']]],
  ['modulename_1540',['ModuleName',['../structsightx_1_1sdk_1_1StreamLog.html#a04ffdc3f91e4e775197be0cde2dd4e19',1,'sightx::sdk::StreamLog']]],
  ['modules_1541',['Modules',['../structsightx_1_1sdk_1_1StreamInfo.html#a2eeb4d9056cd31158600e487d9b987fa',1,'sightx::sdk::StreamInfo']]]
];
