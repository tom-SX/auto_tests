var searchData=
[
  ['name_1542',['Name',['../structsightx_1_1sdk_1_1Attribute.html#a9fa70a2339711cc62308d7e89c8ac654',1,'sightx::sdk::Attribute::Name()'],['../structsightx_1_1sdk_1_1ModuleStatistics.html#a14224bf1e8818961cc49eb09834b2b18',1,'sightx::sdk::ModuleStatistics::Name()'],['../structsightx_1_1sdk_1_1ModuleInfo.html#aa7827fb76cbdb27ea00c7abe5d35e2c5',1,'sightx::sdk::ModuleInfo::Name()']]]
];
