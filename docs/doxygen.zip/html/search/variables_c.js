var searchData=
[
  ['onframeresults_1543',['OnFrameResults',['../structsightx_1_1sdk_1_1Callbacks.html#afa3a18412b14cf50d25f014886fbae81',1,'sightx::sdk::Callbacks']]],
  ['onmessage_1544',['OnMessage',['../structsightx_1_1sdk_1_1LoggerCallbacks.html#a74037f4f5de8b50283fd16419a645616',1,'sightx::sdk::LoggerCallbacks']]],
  ['onserverstatechange_1545',['OnServerStateChange',['../structsightx_1_1sdk_1_1Callbacks.html#a26e78a656e574952304eea527ccdc1ed',1,'sightx::sdk::Callbacks']]],
  ['onstreamevent_1546',['OnStreamEvent',['../structsightx_1_1sdk_1_1Callbacks.html#ace2c46f0dc432932a810cfa347e4f5d0',1,'sightx::sdk::Callbacks']]],
  ['out_1547',['Out',['../structsightx_1_1sdk_1_1EdgeInfo.html#a8c571f4417d3b5ea9c7813a0f6a9a814',1,'sightx::sdk::EdgeInfo']]],
  ['outputs_1548',['Outputs',['../structsightx_1_1sdk_1_1ModuleInfo.html#ace65c8d801a3a14ee14742cd6b53f209',1,'sightx::sdk::ModuleInfo']]]
];
