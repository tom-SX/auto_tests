var structsightx_1_1sdk_1_1Attribute =
[
    [ "Name", "structsightx_1_1sdk_1_1Attribute.html#a9fa70a2339711cc62308d7e89c8ac654", null ],
    [ "Score", "structsightx_1_1sdk_1_1Attribute.html#a2926a4870ca074a30a564b882e5ed6d3", null ],
    [ "Value", "structsightx_1_1sdk_1_1Attribute.html#a16feda0a1b6b3db03df34fbc7189889d", null ]
];