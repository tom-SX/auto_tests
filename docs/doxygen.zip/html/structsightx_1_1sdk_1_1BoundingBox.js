var structsightx_1_1sdk_1_1BoundingBox =
[
    [ "X1", "structsightx_1_1sdk_1_1BoundingBox.html#a5f592a474407ea3220b661e44b9aae23", null ],
    [ "X2", "structsightx_1_1sdk_1_1BoundingBox.html#a0b4d485283df186974bff12005630b8d", null ],
    [ "Y1", "structsightx_1_1sdk_1_1BoundingBox.html#a539ad7c2d790ef307657b41bb9855be9", null ],
    [ "Y2", "structsightx_1_1sdk_1_1BoundingBox.html#af59d2f858919e40ec6bfb1305d5ac19b", null ]
];