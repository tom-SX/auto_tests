var structsightx_1_1sdk_1_1FrameResults =
[
    [ "FrameId", "structsightx_1_1sdk_1_1FrameResults.html#ad8325d45b0b3bafcad03dfda3cb195d3", null ],
    [ "LatencyMs", "structsightx_1_1sdk_1_1FrameResults.html#a75249d2f8b4dd2486f97165a3d2b6749", null ],
    [ "PlatformAltitudeMeters", "structsightx_1_1sdk_1_1FrameResults.html#af35fa930469afa73db4e42f8c6543601", null ],
    [ "PlatformLatitudeDegrees", "structsightx_1_1sdk_1_1FrameResults.html#a8dd4ca0a30840393b82387294a62a19d", null ],
    [ "PlatformLongitudeDegrees", "structsightx_1_1sdk_1_1FrameResults.html#a1673036af9372c158c5d8f73bbe7c3c7", null ],
    [ "StreamId", "structsightx_1_1sdk_1_1FrameResults.html#a847192549648188425f3bdbeba06f254", null ],
    [ "Tracks", "structsightx_1_1sdk_1_1FrameResults.html#a9289d781bf179541c1dfdeaf8736164d", null ]
];