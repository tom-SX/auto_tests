var structsightx_1_1sdk_1_1GrpcSettings =
[
    [ "KeepAlivePeriodInMsecs", "structsightx_1_1sdk_1_1GrpcSettings.html#a23101c290ec83586c37f08f335270b8f", null ],
    [ "Port", "structsightx_1_1sdk_1_1GrpcSettings.html#ac1b09089b86d6e01066452adca8389ea", null ],
    [ "ServerIP", "structsightx_1_1sdk_1_1GrpcSettings.html#aa4ebd8e2fab86392668a775311b58609", null ],
    [ "TimeoutInMsecs", "structsightx_1_1sdk_1_1GrpcSettings.html#a9c8acb4041247cafb356d1fe4ce8100c", null ]
];