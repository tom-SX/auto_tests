var structsightx_1_1sdk_1_1MemoryAllocationInfo =
[
    [ "Allocated", "structsightx_1_1sdk_1_1MemoryAllocationInfo.html#ab4691e7d0bf93d320e94681b7011cfce", null ],
    [ "AllocationsRate", "structsightx_1_1sdk_1_1MemoryAllocationInfo.html#a5275d64268f843cdb5ec79a69058c7e6", null ],
    [ "Limit", "structsightx_1_1sdk_1_1MemoryAllocationInfo.html#a9cf3639c2af6115318cf5920c1b63ae5", null ],
    [ "ReleasesRate", "structsightx_1_1sdk_1_1MemoryAllocationInfo.html#a396d19382ad43a4dc9c3b48a6703858e", null ],
    [ "Used", "structsightx_1_1sdk_1_1MemoryAllocationInfo.html#a5c8e1b1c26a07ed252f7abe77c0c3506", null ]
];