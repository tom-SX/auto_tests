var structsightx_1_1sdk_1_1MessageLog =
[
    [ "Level", "structsightx_1_1sdk_1_1MessageLog.html#ac86929a31ad43f3a9473a084f448c9de", null ],
    [ "Text", "structsightx_1_1sdk_1_1MessageLog.html#a740fa2eaf2ff3154812500ea1de42cb6", null ]
];