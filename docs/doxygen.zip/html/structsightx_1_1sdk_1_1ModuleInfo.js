var structsightx_1_1sdk_1_1ModuleInfo =
[
    [ "Active", "structsightx_1_1sdk_1_1ModuleInfo.html#a2fed645094dc0781bf139aa6231fb040", null ],
    [ "DroppedFrames", "structsightx_1_1sdk_1_1ModuleInfo.html#a63a0c743b4ec875fb9a7e859ccbc1955", null ],
    [ "Enabled", "structsightx_1_1sdk_1_1ModuleInfo.html#a0121e1103e349e3b622e2954b39bbe3d", null ],
    [ "FPS", "structsightx_1_1sdk_1_1ModuleInfo.html#abf7c2e2aa7e11ddbb1ecc2f11c7eda4c", null ],
    [ "Inputs", "structsightx_1_1sdk_1_1ModuleInfo.html#af8ca279cf0c3fec2acef543c2dfda091", null ],
    [ "MaxQueueSize", "structsightx_1_1sdk_1_1ModuleInfo.html#a2c18e11cf655f821e4df48e433df66a4", null ],
    [ "Name", "structsightx_1_1sdk_1_1ModuleInfo.html#aa7827fb76cbdb27ea00c7abe5d35e2c5", null ],
    [ "Outputs", "structsightx_1_1sdk_1_1ModuleInfo.html#ace65c8d801a3a14ee14742cd6b53f209", null ],
    [ "ProcessingTimeMs", "structsightx_1_1sdk_1_1ModuleInfo.html#a26b074838c0e15aa3861212cc8acdae4", null ],
    [ "QueueSize", "structsightx_1_1sdk_1_1ModuleInfo.html#a4877aff18fbacb56d39123ddabc1fcc1", null ],
    [ "ReadOnlySubGraph", "structsightx_1_1sdk_1_1ModuleInfo.html#ad4bf29d75346481dc01e26deac1c8cbc", null ],
    [ "Statistics", "structsightx_1_1sdk_1_1ModuleInfo.html#a45ecee551fed9f5db8f4aa1da32d2395", null ],
    [ "Type", "structsightx_1_1sdk_1_1ModuleInfo.html#a5dffb969cd2ada21f33600464aed1597", null ]
];