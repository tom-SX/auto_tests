var structsightx_1_1sdk_1_1PipelineInfo =
[
    [ "GpuMemoryAllocation", "structsightx_1_1sdk_1_1PipelineInfo.html#a1699a230166ae5d17c20604ffc398bbf", null ],
    [ "PinnedCpuMemoryAllocation", "structsightx_1_1sdk_1_1PipelineInfo.html#a2ea873d84f02b5ee680e13fd32148b0f", null ],
    [ "RAMAllocation", "structsightx_1_1sdk_1_1PipelineInfo.html#a725ba28a625c73e7e30001c0dea147eb", null ],
    [ "Rates", "structsightx_1_1sdk_1_1PipelineInfo.html#adf6631cdfe1c692e645af5e88716ae33", null ],
    [ "UpTime", "structsightx_1_1sdk_1_1PipelineInfo.html#a7b20ef6e2f7bc5ce2d05d649b22aef71", null ]
];