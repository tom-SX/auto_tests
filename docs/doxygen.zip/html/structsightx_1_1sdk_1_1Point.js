var structsightx_1_1sdk_1_1Point =
[
    [ "X", "structsightx_1_1sdk_1_1Point.html#a60147c8f37814a94ab4ce33721eeeb78", null ],
    [ "Y", "structsightx_1_1sdk_1_1Point.html#a89ee211de6c09fbc36de82d3e1aff9d7", null ]
];