var structsightx_1_1sdk_1_1ServerInfo =
[
    [ "Compatible", "structsightx_1_1sdk_1_1ServerInfo.html#a9bdc0035de31facaf32d861e348b8db1", null ],
    [ "HostName", "structsightx_1_1sdk_1_1ServerInfo.html#a0120f9ad6f613c071118fdb331ebe442", null ],
    [ "IP", "structsightx_1_1sdk_1_1ServerInfo.html#a6efbcb445557a83fc406f45c7ae010eb", null ],
    [ "Port", "structsightx_1_1sdk_1_1ServerInfo.html#ab1438e89b951bf5c4eace3d160fedf32", null ],
    [ "Project", "structsightx_1_1sdk_1_1ServerInfo.html#a2b16de64565f1e73ca69535507a9f32b", null ],
    [ "Version", "structsightx_1_1sdk_1_1ServerInfo.html#a467f809e8457a4cf6ac7be3beeb3e63b", null ]
];