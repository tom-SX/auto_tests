var structsightx_1_1sdk_1_1SingleFrameOutputType =
[
    [ "Type", "structsightx_1_1sdk_1_1SingleFrameOutputType.html#ae3b655ee10f27d8afe988d2bccf25737", null ]
];