var structsightx_1_1sdk_1_1StreamInfo =
[
    [ "DroppedFrames", "structsightx_1_1sdk_1_1StreamInfo.html#a11e4c3f123c0a6ee7d4da65a5c876fe4", null ],
    [ "Edges", "structsightx_1_1sdk_1_1StreamInfo.html#a1293325da25a1fa9ce5b2fd53b393f52", null ],
    [ "FPS", "structsightx_1_1sdk_1_1StreamInfo.html#a4fe8b4fd2f86882633ca287471e411e8", null ],
    [ "Height", "structsightx_1_1sdk_1_1StreamInfo.html#acea1b5c069f605e20fdc3e48a29779eb", null ],
    [ "LatencyMs", "structsightx_1_1sdk_1_1StreamInfo.html#a05a01759ab924714a0dfd56d81262839", null ],
    [ "Modules", "structsightx_1_1sdk_1_1StreamInfo.html#a2eeb4d9056cd31158600e487d9b987fa", null ],
    [ "ProcessedFrames", "structsightx_1_1sdk_1_1StreamInfo.html#a38890d6001ae961d18fb63bf02b3c807", null ],
    [ "PTS", "structsightx_1_1sdk_1_1StreamInfo.html#a3a0a9563ea85e1090fc0579ac3096dd7", null ],
    [ "State", "structsightx_1_1sdk_1_1StreamInfo.html#a222cfef4172c68092e16c0a57d92e84e", null ],
    [ "UpTime", "structsightx_1_1sdk_1_1StreamInfo.html#af7879b5b3a082d92a1d614839daa5ebf", null ],
    [ "Width", "structsightx_1_1sdk_1_1StreamInfo.html#a6088e8627705b3664b3cc1e1b788a3c0", null ]
];