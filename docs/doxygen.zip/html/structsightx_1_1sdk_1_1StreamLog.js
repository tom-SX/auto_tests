var structsightx_1_1sdk_1_1StreamLog =
[
    [ "Event", "structsightx_1_1sdk_1_1StreamLog.html#aff91393d5187e92f37219bb0db73222c", null ],
    [ "ModuleName", "structsightx_1_1sdk_1_1StreamLog.html#a04ffdc3f91e4e775197be0cde2dd4e19", null ],
    [ "StreamId", "structsightx_1_1sdk_1_1StreamLog.html#ad129d26f2a6a0fb786d0ba8ff0bada06", null ],
    [ "Text", "structsightx_1_1sdk_1_1StreamLog.html#ad19b0644b2f773e09fdf77126c41ffa2", null ]
];