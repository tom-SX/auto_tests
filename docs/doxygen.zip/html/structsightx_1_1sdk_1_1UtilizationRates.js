var structsightx_1_1sdk_1_1UtilizationRates =
[
    [ "GpuFreeMemoryBytes", "structsightx_1_1sdk_1_1UtilizationRates.html#aa58e695184e113b282762467303b679c", null ],
    [ "GpuLoad", "structsightx_1_1sdk_1_1UtilizationRates.html#aba0a57a1534b789fd63df3ff6f5cb414", null ],
    [ "GpuTemperature", "structsightx_1_1sdk_1_1UtilizationRates.html#a4f02e075b8ec0527187bd089b339d3b2", null ],
    [ "GpuTotalMemoryBytes", "structsightx_1_1sdk_1_1UtilizationRates.html#af60c14858a0b525c548d88c02592e396", null ],
    [ "PipelineCpuLoad", "structsightx_1_1sdk_1_1UtilizationRates.html#aeff83ea12f23099f7e876bbd4eb467cc", null ],
    [ "PipelineResidentMemoryBytes", "structsightx_1_1sdk_1_1UtilizationRates.html#aa53d32636b24149bf9060460e4e98960", null ],
    [ "PipelineVirtualMemoryBytes", "structsightx_1_1sdk_1_1UtilizationRates.html#a4f429cd7ddb1b0256bbad43da2086868", null ],
    [ "SystemAvailableStorageBytes", "structsightx_1_1sdk_1_1UtilizationRates.html#a249cac5492faaa709baee9026d8f2ddb", null ],
    [ "SystemCpuCores", "structsightx_1_1sdk_1_1UtilizationRates.html#afb443f41fc98acb30670f6a0ef3b3567", null ],
    [ "SystemCpuTemperature", "structsightx_1_1sdk_1_1UtilizationRates.html#a4e40126a273b8c15200fdf1b087d29e7", null ],
    [ "SystemFreeMemoryBytes", "structsightx_1_1sdk_1_1UtilizationRates.html#a50ce3a2dedd91c9bb1c1a92f1b56087e", null ],
    [ "SystemFreeSwapBytes", "structsightx_1_1sdk_1_1UtilizationRates.html#a020cb4224d0d4fe90687791f9f582913", null ],
    [ "SystemTotalMemoryBytes", "structsightx_1_1sdk_1_1UtilizationRates.html#a877d3747e5abe8fc7cd2091f637b0080", null ],
    [ "SystemTotalStorageBytes", "structsightx_1_1sdk_1_1UtilizationRates.html#a858272767a2f7399b92d43d1c6561bc3", null ],
    [ "SystemTotalSwapBytes", "structsightx_1_1sdk_1_1UtilizationRates.html#aa006ba7f0d55ab20a1bdc08084a6de4d", null ]
];