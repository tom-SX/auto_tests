var structsightx_1_1sdk_1_1VelocityVector =
[
    [ "X", "structsightx_1_1sdk_1_1VelocityVector.html#a42f1294ce56508d451081efe98532ed1", null ],
    [ "Y", "structsightx_1_1sdk_1_1VelocityVector.html#a3b467fa4f2f0c023f46e90a68cc9bae0", null ]
];